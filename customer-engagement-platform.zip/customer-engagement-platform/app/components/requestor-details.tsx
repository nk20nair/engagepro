import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

const departments = [
  "Two-wheeler", "Passenger Vehicle", "Small Commercial Vehicle", "Light Commercial Vehicle",
  "Medium & Heavy Commercial Vehicle", "Construction Equipment", "Tractor and Farm Equipment",
  "Affordable Home Loan", "Operations", "Administration", "MIS", "Credit", "Legal", "HR",
  "L&D", "Compliance", "IT", "Others"
]

const requestMethods = ["Email", "SMS", "WhatsApp", "Teams Meeting", "Face-To-Face", "Phone Call"]

export function RequestorDetails() {
  const [requestorName, setRequestorName] = useState('')
  const [department, setDepartment] = useState('')
  const [otherDepartment, setOtherDepartment] = useState('')
  const [requestedVia, setRequestedVia] = useState('')
  const [emailSubject, setEmailSubject] = useState('')
  const [teamsSubject, setTeamsSubject] = useState('')
  const [requestDate, setRequestDate] = useState('')
  const [priority, setPriority] = useState('')
  const [requestorEmail, setRequestorEmail] = useState('')

  const validateEmail = (email: string) => {
    return email.endsWith('@indusind.com')
  }

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="requestor-name">Name of Requestor</Label>
        <Input
          id="requestor-name"
          value={requestorName}
          onChange={(e) => setRequestorName(e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="department">Department of Requestor</Label>
        <Select onValueChange={setDepartment} value={department}>
          <SelectTrigger>
            <SelectValue placeholder="Select department" />
          </SelectTrigger>
          <SelectContent>
            {departments.map((dept) => (
              <SelectItem key={dept} value={dept}>{dept}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {department === 'Others' && (
        <div>
          <Label htmlFor="other-department">Other Department</Label>
          <Input
            id="other-department"
            value={otherDepartment}
            onChange={(e) => setOtherDepartment(e.target.value)}
          />
        </div>
      )}

      <div>
        <Label htmlFor="requested-via">Requested via</Label>
        <Select onValueChange={setRequestedVia} value={requestedVia}>
          <SelectTrigger>
            <SelectValue placeholder="Select request method" />
          </SelectTrigger>
          <SelectContent>
            {requestMethods.map((method) => (
              <SelectItem key={method} value={method}>{method}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {requestedVia === 'Email' && (
        <div>
          <Label htmlFor="email-subject">Email Subject Line</Label>
          <Input
            id="email-subject"
            value={emailSubject}
            onChange={(e) => setEmailSubject(e.target.value)}
          />
        </div>
      )}

      {requestedVia === 'Teams Meeting' && (
        <div>
          <Label htmlFor="teams-subject">Teams Meeting Subject Line</Label>
          <Input
            id="teams-subject"
            value={teamsSubject}
            onChange={(e) => setTeamsSubject(e.target.value)}
          />
        </div>
      )}

      <div>
        <Label htmlFor="request-date">Date of Request</Label>
        <Input
          id="request-date"
          type="date"
          value={requestDate}
          onChange={(e) => setRequestDate(e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="priority">Priority</Label>
        <Select onValueChange={setPriority} value={priority}>
          <SelectTrigger>
            <SelectValue placeholder="Select priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="requestor-email">Email Address of Requestor</Label>
        <Textarea
          id="requestor-email"
          value={requestorEmail}
          onChange={(e) => setRequestorEmail(e.target.value)}
          placeholder="Enter email addresses (one per line)"
        />
        <p className="text-sm text-gray-500 mt-1">
          Only @indusind.com email addresses are allowed. Add multiple email addresses on separate lines.
        </p>
      </div>
    </div>
  )
}

