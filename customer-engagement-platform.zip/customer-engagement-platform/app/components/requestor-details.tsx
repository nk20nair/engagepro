import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const departments = [
  "Two-wheeler", "Passenger Vehicle", "Small Commercial Vehicle", "Light Commercial Vehicle",
  "Medium & Heavy Commercial Vehicle", "Construction Equipment", "Tractor and Farm Equipment",
  "Affordable Home Loan", "Operations", "Administration", "MIS", "Credit", "Legal", "HR",
  "L&D", "Compliance", "IT", "Others"
]

const requestMethods = ["Email", "SMS", "WhatsApp", "Teams Meeting", "Face-To-Face", "Phone Call"]

interface RequestorDetailsProps {
  onNext: () => void;
}

export function RequestorDetails({ onNext }: RequestorDetailsProps) {
  const [requestorName, setRequestorName] = useState('')
  const [department, setDepartment] = useState('')
  const [otherDepartment, setOtherDepartment] = useState('')
  const [requestedVia, setRequestedVia] = useState('')
  const [emailSubject, setEmailSubject] = useState('')
  const [teamsSubject, setTeamsSubject] = useState('')
  const [requestDate, setRequestDate] = useState('')
  const [priority, setPriority] = useState('')
  const [requestorEmail, setRequestorEmail] = useState('')

  const validateEmail = (email: string) => {
    return email.endsWith('@indusind.com')
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Perform validation here
    const emails = requestorEmail.split('\n').map(email => email.trim())
    if (emails.every(validateEmail)) {
      onNext()
    } else {
      alert('Please enter valid @indusind.com email addresses')
    }
  }

  return (
    <Card>
      <form onSubmit={handleSubmit}>
        <CardHeader>
          <CardTitle>Requestor Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="requestor-name">Name of Requestor</Label>
            <Input
              id="requestor-name"
              value={requestorName}
              onChange={(e) => setRequestorName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="department">Department of Requestor</Label>
            <Select onValueChange={setDepartment} value={department} required>
              <SelectTrigger>
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {department === 'Others' && (
            <div className="space-y-2">
              <Label htmlFor="other-department">Other Department</Label>
              <Input
                id="other-department"
                value={otherDepartment}
                onChange={(e) => setOtherDepartment(e.target.value)}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="requested-via">Requested via</Label>
            <Select onValueChange={setRequestedVia} value={requestedVia} required>
              <SelectTrigger>
                <SelectValue placeholder="Select request method" />
              </SelectTrigger>
              <SelectContent>
                {requestMethods.map((method) => (
                  <SelectItem key={method} value={method}>{method}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {requestedVia === 'Email' && (
            <div className="space-y-2">
              <Label htmlFor="email-subject">Email Subject Line</Label>
              <Input
                id="email-subject"
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
                required
              />
            </div>
          )}

          {requestedVia === 'Teams Meeting' && (
            <div className="space-y-2">
              <Label htmlFor="teams-subject">Teams Meeting Subject Line</Label>
              <Input
                id="teams-subject"
                value={teamsSubject}
                onChange={(e) => setTeamsSubject(e.target.value)}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="request-date">Date of Request</Label>
            <Input
              id="request-date"
              type="date"
              value={requestDate}
              onChange={(e) => setRequestDate(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="priority">Priority</Label>
            <Select onValueChange={setPriority} value={priority} required>
              <SelectTrigger>
                <SelectValue placeholder="Select priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="requestor-email">Email Address of Requestor</Label>
            <Textarea
              id="requestor-email"
              value={requestorEmail}
              onChange={(e) => setRequestorEmail(e.target.value)}
              placeholder="Enter email addresses (one per line)"
              required
            />
            <p className="text-sm text-gray-500 mt-1">
              Only @indusind.com email addresses are allowed. Add multiple email addresses on separate lines.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit">Next</Button>
        </CardFooter>
      </form>
    </Card>
  )
}

