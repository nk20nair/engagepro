'use client'

import Link from 'next/link'
import { Home, Users, BarChart2, Mail, Settings, LogOut } from 'lucide-react'
import { useAuth } from '../context/auth-context'
import { useRouter } from 'next/navigation'

export function Sidebar() {
  const { logout } = useAuth()
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push('/login')
  }

  return (
    <div className="w-64 bg-white h-full shadow-md">
      <div className="flex items-center justify-center h-16 border-b">
        <span className="text-2xl font-semibold">EngagePro</span>
      </div>
      <nav className="mt-6">
        <Link href="/dashboard" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <Home className="h-5 w-5 mr-3" />
          Dashboard
        </Link>
        <Link href="/users" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <Users className="h-5 w-5 mr-3" />
          Users
        </Link>
        <Link href="/analytics" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <BarChart2 className="h-5 w-5 mr-3" />
          Analytics
        </Link>
        <Link href="/campaigns" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <Mail className="h-5 w-5 mr-3" />
          Campaigns
        </Link>
        <Link href="/settings" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <Settings className="h-5 w-5 mr-3" />
          Settings
        </Link>
        <button onClick={handleLogout} className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100 w-full text-left">
          <LogOut className="h-5 w-5 mr-3" />
          Logout
        </button>
      </nav>
    </div>
  )
}

