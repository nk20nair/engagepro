import Link from 'next/link'
import { Home, PlusCircle, List, BarChart } from 'lucide-react'

export function Sidebar() {
  return (
    <div className="w-64 bg-white h-full shadow-md">
      <div className="flex items-center justify-center h-16 border-b">
        <span className="text-2xl font-semibold">EngagePro</span>
      </div>
      <nav className="mt-6">
        <Link href="/" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <Home className="h-5 w-5 mr-3" />
          Dashboard
        </Link>
        <Link href="/campaigns/create" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <PlusCircle className="h-5 w-5 mr-3" />
          Create Campaign
        </Link>
        <Link href="/campaigns" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <List className="h-5 w-5 mr-3" />
          Campaigns
        </Link>
        <Link href="/analytics" className="flex items-center px-6 py-3 text-gray-700 hover:bg-gray-100">
          <BarChart className="h-5 w-5 mr-3" />
          Analytics
        </Link>
      </nav>
    </div>
  )
}

