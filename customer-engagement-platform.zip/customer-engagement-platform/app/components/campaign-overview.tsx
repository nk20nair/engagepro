import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail } from 'lucide-react'

export function CampaignOverview() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Campaign Overview</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-center h-64">
        <div className="text-center">
          <Mail className="h-16 w-16 text-gray-400 mx-auto" />
          <p className="mt-4 text-gray-500">Campaign performance overview goes here</p>
        </div>
      </CardContent>
    </Card>
  )
}

