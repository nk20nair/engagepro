import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart } from 'lucide-react'

export function UserAnalytics() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>User Analytics</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-center h-64">
        <div className="text-center">
          <BarChart className="h-16 w-16 text-gray-400 mx-auto" />
          <p className="mt-4 text-gray-500">User analytics visualization goes here</p>
        </div>
      </CardContent>
    </Card>
  )
}

