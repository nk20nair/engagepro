import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart } from 'lucide-react'

export function SegmentationChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>User Segmentation</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-center h-64">
        <div className="text-center">
          <PieChart className="h-16 w-16 text-gray-400 mx-auto" />
          <p className="mt-4 text-gray-500">User segmentation chart goes here</p>
        </div>
      </CardContent>
    </Card>
  )
}

