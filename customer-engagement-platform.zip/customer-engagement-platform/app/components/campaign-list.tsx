import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const campaigns = [
  { id: 1, name: "Summer Sale", type: "SMS", status: "Active", requestor: "John Doe", approver: "Jane Smith" },
  { id: 2, name: "Newsletter", type: "Email", status: "Pending", requestor: "Alice Johnson", approver: "Bob Williams" },
  { id: 3, name: "Product Launch", type: "WhatsApp", status: "Active", requestor: "Charlie Brown", approver: "Diana Davis" },
]

export function CampaignList() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Campaigns</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Requestor</TableHead>
              <TableHead>Approver</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {campaigns.map((campaign) => (
              <TableRow key={campaign.id}>
                <TableCell>{campaign.name}</TableCell>
                <TableCell>{campaign.type}</TableCell>
                <TableCell>{campaign.status}</TableCell>
                <TableCell>{campaign.requestor}</TableCell>
                <TableCell>{campaign.approver}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

