"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Trash2 } from 'lucide-react'
import EmojiPicker, { EmojiClickData } from 'emoji-picker-react';

const isValidUrl = (string: string) => {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
};

export default function CreateCampaign() {
  const [campaignType, setCampaignType] = useState("sms")
  const [content, setContent] = useState("")
  const [variables, setVariables] = useState<string[]>([])
  const [shortUrls, setShortUrls] = useState<Record<string, string>>({});
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const [characterCount, setCharacterCount] = useState(0)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const [cta, setCta] = useState("") // New state for CTA
  const [ctaLink, setCtaLink] = useState("") // Added CTA hyperlink state
  const [selectedImage, setSelectedImage] = useState<File | null>(null); // Added image state
  const router = useRouter()
  const { toast } = useToast()

  const addVariable = () => {
    const newVar = `var${variables.length + 1}`;
    setVariables([...variables, newVar]);
    setVariableValues({ ...variableValues, [newVar]: '' });
    const textArea = document.getElementById('content') as HTMLTextAreaElement;
    const cursorPos = textArea.selectionStart;
    const textBefore = content.substring(0, cursorPos);
    const textAfter = content.substring(cursorPos, content.length);
    setContent(textBefore + `{#${newVar}#}` + textAfter);
    setTimeout(() => {
      textArea.focus();
      textArea.setSelectionRange(cursorPos + newVar.length + 4, cursorPos + newVar.length + 4);
    }, 0);
  };

  const handleEmojiClick = (emojiData: EmojiClickData) => {
    setContent((prevContent) => prevContent + emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast({
          title: "Error",
          description: "Image size should be less than 1MB",
          variant: "destructive",
        });
        return;
      }
      const img = new Image();
      img.onload = () => {
        if (img.width / img.height !== 2) {
          toast({
            title: "Error",
            description: "Image should have a 2:1 aspect ratio",
            variant: "destructive",
          });
        } else {
          setSelectedImage(file);
        }
      };
      img.src = URL.createObjectURL(file);
    }
  };

  const handleCampaignTypeChange = (value: string) => {
    setCampaignType(value);
    if (value === "sms") {
      setSelectedImage(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const campaignData = {
      campaignType,
      content,
      variables,
      shortUrls,
      variableValues,
      image: selectedImage,
      ...(campaignType === "whatsapp" && { cta, ctaLink })
    }
    console.log("Campaign created:", campaignData)
    toast({
      title: "Campaign created",
      description: "Your campaign has been successfully created and is pending approval.",
    })
    router.push("/campaigns")
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Create Campaign</h1>
      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Campaign Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="campaign-type">Campaign Type</Label>
              <Select onValueChange={handleCampaignTypeChange} defaultValue={campaignType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="content">Content</Label>
              <div className="relative">
                <Textarea
                  id="content"
                  placeholder="Enter your campaign content here"
                  value={content}
                  onChange={(e) => {
                    setContent(e.target.value);
                    setCharacterCount(e.target.value.length);
                  }}
                  onFocus={(e) => e.currentTarget.setSelectionRange(e.currentTarget.selectionStart, e.currentTarget.selectionStart)}
                  rows={5}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="absolute right-2 bottom-2"
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                >
                  😊
                </Button>
              </div>
              {showEmojiPicker && (
                <div className="absolute z-10">
                  <EmojiPicker onEmojiClick={handleEmojiClick} />
                </div>
              )}
            </div>
            {campaignType !== "sms" && (
              <div className="space-y-2">
                <Label htmlFor="image-upload">Upload Image (2:1 ratio, max 1MB)</Label>
                <Input
                  id="image-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                />
              </div>
            )}
            {campaignType === "whatsapp" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="cta">Call to Action</Label>
                  <Input
                    id="cta"
                    placeholder="Enter your call to action text"
                    value={cta}
                    onChange={(e) => setCta(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ctaLink">CTA Link</Label>
                  <Input
                    id="ctaLink"
                    placeholder="Enter link, phone number, or email address"
                    value={ctaLink}
                    onChange={(e) => setCtaLink(e.target.value)}
                  />
                </div>
              </>
            )}
            <div className="space-y-2">
              <Button type="button" onClick={addVariable}>Add Variable</Button>
              {variables.map((variable, index) => (
                <div key={index} className="flex flex-col space-y-2 w-full">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor={`var-${index}`} className="w-24">{variable}</Label>
                    <Input 
                      id={`var-${index}`} 
                      placeholder={`Enter ${variable} value`}
                      value={variableValues[variable] || ''}
                      onChange={(e) => {
                        const newValue = e.target.value;
                        setVariableValues({...variableValues, [variable]: newValue});
                        if (isValidUrl(newValue) && !shortUrls[variable]) {
                          setShortUrls({...shortUrls, [variable]: ''});
                        }
                      }}
                      className="flex-grow"
                    />
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => {
                        setVariables(variables.filter(v => v !== variable));
                        const { [variable]: _, ...restVariables } = variableValues;
                        setVariableValues(restVariables);
                        const { [variable]: __, ...restShortUrls } = shortUrls;
                        setShortUrls(restShortUrls);
                        setContent(content.replace(new RegExp(`\\{#${variable}#\\}`, 'g'), ''));
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  {shortUrls.hasOwnProperty(variable) && (
                    <div className="flex items-center space-x-2 ml-24">
                      <Label htmlFor={`shortUrl-${index}`} className="w-24">Short URL</Label>
                      <Input
                        id={`shortUrl-${index}`}
                        placeholder="Enter short URL"
                        value={shortUrls[variable] || ''}
                        onChange={(e) => setShortUrls({...shortUrls, [variable]: e.target.value})}
                        className="flex-grow"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
            {campaignType === "sms" && (
              <>
                <div className="space-y-2">
                  <Label>SMS Preview</Label>
                  <div className="bg-gray-100 p-4 rounded-lg">
                    <div className="bg-blue-500 text-white p-3 rounded-lg inline-block max-w-xs">
                      {selectedImage && (
                        <img
                          src={URL.createObjectURL(selectedImage)}
                          alt="Uploaded image"
                          className="w-full h-auto mb-2 rounded"
                        />
                      )}
                      <p className="text-sm">
                        {content.replace(/\{#(\w+)#\}/g, (match, v) => {
                          if (variables.includes(v)) {
                            if (shortUrls.hasOwnProperty(v) && shortUrls[v]) {
                              return shortUrls[v];
                            }
                            return variableValues[v] || match;
                          }
                          return '';
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 mt-2">
                    Characters: {characterCount} | SMS Parts: {Math.ceil(characterCount / 160)}
                  </div>
                </div>
              </>
            )}
            {campaignType === "whatsapp" && (
              <>
                <div className="space-y-2">
                  <Label>WhatsApp Preview</Label>
                  <div className="bg-[#E5DDD5] p-4 rounded-lg max-w-sm">
                    <div className="bg-white rounded-lg shadow-md p-3 relative">
                      <div className="bg-[#DCF8C6] text-black p-3 rounded-lg relative mb-2">
                        {selectedImage && (
                          <img
                            src={URL.createObjectURL(selectedImage)}
                            alt="Uploaded image"
                            className="w-full h-auto mb-2 rounded"
                          />
                        )}
                        <p className="text-sm whitespace-pre-wrap break-words">
                          {content.replace(/\{#(\w+)#\}/g, (match, v) =>
                            variables.includes(v)
                              ? (shortUrls[v] || variableValues[v] || match)
                              : ''
                          )}
                        </p>
                        {cta && (
                          <>
                            <hr className="my-2 border-gray-300" />
                            <div className="flex items-center justify-center text-[#25D366] font-medium">
                              {isValidUrl(cta) ? (
                                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                </svg>
                              ) : (
                                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                              )}
                              {cta}
                            </div>
                          </>
                        )}
                        <span className="text-[10px] text-gray-500 absolute bottom-1 right-2 flex items-center">
                          {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          <svg className="w-3 h-3 ml-1 text-gray-400" viewBox="0 0 16 15" fill="currentColor">
                            <path d="M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.879a.32.32 0 0 1-.484.033l-.358-.325a.319.319 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l1.32 1.266c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.064-.512zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.366.366 0 0 0-.515.006l-.423.433a.364.364 0 0 0 .006.514l3.258 3.185c.143.14.361.125.484-.033l6.272-8.048a.365.365 0 0 0-.063-.51z" />
                          </svg>
                        </span>
                      </div>
                      <div className="flex items-center mt-2">
                        <svg className="w-5 h-5 text-gray-400 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <input
                          type="text"
                          placeholder="Type a message"
                          className="bg-white text-sm p-2 rounded-full flex-grow focus:outline-none focus:ring-2 focus:ring-green-500"
                          readOnly
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
          <CardFooter>
            <Button type="submit">Create Campaign</Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

