"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

export default function CreateCampaign() {
  const [campaignType, setCampaignType] = useState("sms")
  const [content, setContent] = useState("")
  const [variables, setVariables] = useState<string[]>([])
  const [shortUrl, setShortUrl] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Campaign created:", { campaignType, content, variables, shortUrl })
    toast({
      title: "Campaign created",
      description: "Your campaign has been successfully created and is pending approval.",
    })
    router.push("/campaigns")
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Create Campaign</h1>
      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Campaign Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="campaign-type">Campaign Type</Label>
              <Select onValueChange={setCampaignType} defaultValue={campaignType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {campaignType === "sms" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="variables">Variables (comma-separated)</Label>
                  <Input
                    id="variables"
                    placeholder="e.g., name, date, url"
                    value={variables.join(", ")}
                    onChange={(e) => setVariables(e.target.value.split(", ").filter(Boolean))}
                  />
                </div>
                {variables.includes("url") && (
                  <div className="space-y-2">
                    <Label htmlFor="shortUrl">Short URL</Label>
                    <Input
                      id="shortUrl"
                      placeholder="Enter short URL"
                      value={shortUrl}
                      onChange={(e) => setShortUrl(e.target.value)}
                    />
                  </div>
                )}
                <div className="space-y-2">
                  <Label>Preview</Label>
                  <Card className="p-4 bg-gray-100">
                    <p>{content.replace(/\{(\w+)\}/g, (_, v) => 
                      v === 'url' ? shortUrl : `{${v}}`
                    )}</p>
                  </Card>
                </div>
              </>
            )}
            <div className="space-y-2">
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                placeholder="Enter your campaign content here"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={5}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit">Create Campaign</Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

