"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Trash2 } from 'lucide-react'

const isValidUrl = (string: string) => {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
};

export default function CreateCampaign() {
  const [campaignType, setCampaignType] = useState("sms")
  const [content, setContent] = useState("")
  const [variables, setVariables] = useState<string[]>([])
  const [shortUrls, setShortUrls] = useState<Record<string, string>>({});
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const [characterCount, setCharacterCount] = useState(0); // Added character count state
  const router = useRouter()
  const { toast } = useToast()

  const addVariable = () => {
    const newVar = `var${variables.length + 1}`;
    setVariables([...variables, newVar]);
    setVariableValues({ ...variableValues, [newVar]: '' });
    const textArea = document.getElementById('content') as HTMLTextAreaElement;
    const cursorPos = textArea.selectionStart;
    const textBefore = content.substring(0, cursorPos);
    const textAfter = content.substring(cursorPos, content.length);
    setContent(textBefore + `{#${newVar}#}` + textAfter);
    setTimeout(() => {
      textArea.focus();
      textArea.setSelectionRange(cursorPos + newVar.length + 4, cursorPos + newVar.length + 4);
    }, 0);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Campaign created:", { campaignType, content, variables, shortUrls, variableValues })
    toast({
      title: "Campaign created",
      description: "Your campaign has been successfully created and is pending approval.",
    })
    router.push("/campaigns")
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Create Campaign</h1>
      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Campaign Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="campaign-type">Campaign Type</Label>
              <Select onValueChange={setCampaignType} defaultValue={campaignType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                placeholder="Enter your campaign content here"
                value={content}
                onChange={(e) => {
                  setContent(e.target.value); // Updated onChange handler
                  setCharacterCount(e.target.value.length); // Added character count update
                }}
                onFocus={(e) => e.currentTarget.setSelectionRange(e.currentTarget.selectionStart, e.currentTarget.selectionStart)}
                rows={5}
              />
            </div>
            <div className="space-y-2">
              <Button type="button" onClick={addVariable}>Add Variable</Button>
              {variables.map((variable, index) => (
                <div key={index} className="flex flex-col space-y-2 w-full">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor={`var-${index}`} className="w-24">{variable}</Label>
                    <Input 
                      id={`var-${index}`} 
                      placeholder={`Enter ${variable} value`}
                      value={variableValues[variable] || ''}
                      onChange={(e) => {
                        const newValue = e.target.value;
                        setVariableValues({...variableValues, [variable]: newValue});
                        if (isValidUrl(newValue) && !shortUrls[variable]) {
                          setShortUrls({...shortUrls, [variable]: ''});
                        }
                      }}
                      className="flex-grow"
                    />
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => {
                        setVariables(variables.filter(v => v !== variable));
                        const { [variable]: _, ...restVariables } = variableValues;
                        setVariableValues(restVariables);
                        const { [variable]: __, ...restShortUrls } = shortUrls;
                        setShortUrls(restShortUrls);
                        setContent(content.replace(new RegExp(`\\{#${variable}#\\}`, 'g'), ''));
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  {shortUrls.hasOwnProperty(variable) && (
                    <div className="flex items-center space-x-2 ml-24">
                      <Label htmlFor={`shortUrl-${index}`} className="w-24">Short URL</Label>
                      <Input
                        id={`shortUrl-${index}`}
                        placeholder="Enter short URL"
                        value={shortUrls[variable] || ''}
                        onChange={(e) => setShortUrls({...shortUrls, [variable]: e.target.value})}
                        className="flex-grow"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
            {campaignType === "sms" && (
              <>
                <div className="space-y-2">
                  <Label>SMS Preview</Label>
                  <div className="bg-gray-100 p-4 rounded-lg">
                    <div className="bg-blue-500 text-white p-3 rounded-lg inline-block max-w-xs">
                      <p className="text-sm">
                        {content.replace(/\{#(\w+)#\}/g, (match, v) => {
                          if (variables.includes(v)) {
                            if (shortUrls.hasOwnProperty(v) && shortUrls[v]) {
                              return shortUrls[v];
                            }
                            return variableValues[v] || match;
                          }
                          return '';
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 mt-2">
                    Characters: {characterCount} | SMS Parts: {Math.ceil(characterCount / 160)}
                  </div>
                </div>
              </>
            )}
            {campaignType === "whatsapp" && (
              <>
                <div className="space-y-2">
                  <Label>WhatsApp Preview</Label>
                  <div className="bg-gray-100 p-4 rounded-lg">
                    <div className="bg-[#DCF8C6] text-black p-3 rounded-lg inline-block max-w-xs relative">
                      <p className="text-sm mb-2">
                        {content.replace(/\{#(\w+)#\}/g, (match, v) => {
                          if (variables.includes(v)) {
                            if (shortUrls.hasOwnProperty(v) && shortUrls[v]) {
                              return shortUrls[v];
                            }
                            return variableValues[v] || match;
                          }
                          return '';
                        })}
                      </p>
                      <span className="text-xs text-gray-500 absolute bottom-1 right-2">
                        {new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </span>
                      <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-[#DCF8C6] transform rotate-45"></div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
          <CardFooter>
            <Button type="submit">Create Campaign</Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

